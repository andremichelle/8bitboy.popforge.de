>>> 8BitBoy will not run on your local system, until you
changed the security settings of the adobe flash player!

visit http://8bitboy.popforge.de for more information